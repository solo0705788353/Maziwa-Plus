package net.novacent.maziwaplus.ui.collections

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.MilkCollection


/**
 * Created by kibichii on 9/5/2018.
 */
class CollectionsAdapter(var context: Context, var items: List<MilkCollection>, var itemListener: CollectionsContract.Item) : RecyclerView.Adapter<CollectionViewHolder>() {
    var mLayoutInflater: LayoutInflater

    init {
        mLayoutInflater = LayoutInflater.from(context)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): CollectionViewHolder {
        var view = mLayoutInflater.inflate(R.layout.item_collection, p0, false)

        return CollectionViewHolder(view)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(p0: CollectionViewHolder, p1: Int) {
        var milkCollection = items[p1]
        p0.bind(milkCollection)
    }
}