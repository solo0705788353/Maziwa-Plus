package net.novacent.maziwaplus.utils.scheduler

import io.reactivex.Scheduler

/**
 * Created by KEVIN on 3/14/2018.
 */
interface SchedulerProvider {
    fun ui(): Scheduler

    fun computation(): Scheduler

    fun trampoline(): Scheduler

    fun newThread(): Scheduler

    fun io(): Scheduler
}