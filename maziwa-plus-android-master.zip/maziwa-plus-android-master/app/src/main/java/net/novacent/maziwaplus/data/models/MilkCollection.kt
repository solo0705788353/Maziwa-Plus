package net.novacent.maziwaplus.data.models

import java.io.Serializable
import java.util.*

/**
 * Created by kibichii on 8/16/2018.
 */
data class MilkCollection(
        var id: Long = 0,
        var collectionDate: Date = Date(),
        var litres: Double = 0.0,
        var weight: Double = 0.0,
        var phValue: Double = 0.0,
        var boilingTest: Boolean = false,
        var alcoholContent: Double = 0.0,
        var supplierId: Long = 0,
        var supplier: Farmer? = Farmer(),
        var agentId: Long = 0,
        var createdAt: Date? = null,
        var updatedAt: Date? = null
) : Serializable