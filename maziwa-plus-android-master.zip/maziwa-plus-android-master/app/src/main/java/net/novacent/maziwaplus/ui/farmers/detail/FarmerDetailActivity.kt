package net.novacent.maziwaplus.ui.farmers.detail

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.widget.TextView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.FarmerDetail
import net.novacent.maziwaplus.ui.collections.form.CollectionFormActivity
import net.novacent.maziwaplus.ui.farmers.form.extra.FarmerExtraFormActivity
import org.w3c.dom.Text

class FarmerDetailActivity : AppCompatActivity() {
    companion object {
        public val FARMER_EXTRA: String = "farmer_extra"
        private val FARMER_DETAIL_UPDATE_REQUEST_CODE: Int = 401
    }

    val mToolbar: Toolbar by bindView(R.id.toolbar)
    val mFarmerRefresh: SwipeRefreshLayout by bindView(R.id.farmer_refresh)
    val mCollectMilk: AppCompatButton by bindView(R.id.button_collect_milk)
    val mUpdateDetails: AppCompatButton by bindView(R.id.button_update_details)

    val mFarmerName: TextView by bindView(R.id.farmer_name)
    val mFarmerSupplyNumber: TextView by bindView(R.id.farmer_supply_number)
    val mFarmerPhoneNumber: TextView by bindView(R.id.farmer_phone_number)

    val mFarmerTotalCollections: TextView by bindView(R.id.farmer_total_collections)
    val mFarmerHerdSize: TextView by bindView(R.id.farmer_detail_herd_size)
    val mFarmerLandSize: TextView by bindView(R.id.farmer_detail_land_size)
    val mFarmerFeedsType: TextView by bindView(R.id.farmer_detail_feeds_type)
    val mFarmerOtherFormsOfFarming: TextView by bindView(R.id.farmer_detail_other_farming_forms)

    var mFarmer: Farmer? = null

    private var mMap: GoogleMap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_detail)

        setSupportActionBar(mToolbar)

        mFarmer = intent.getSerializableExtra(FARMER_EXTRA) as Farmer?

        if (supportActionBar != null) {
            supportActionBar?.title = mFarmer?.getFullName()
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
        init()

    }

    private fun init() {

        mFarmerName.text = mFarmer?.getFullName()
        mFarmerSupplyNumber.text = mFarmer?.supplyNumber
        mFarmerPhoneNumber.text = mFarmer?.phoneNumber

        mFarmerRefresh.setDistanceToTriggerSync(999999)

        mFarmerTotalCollections.text = "${mFarmer?.collectionsSummary?.weight.toString()} Kgs"

        this.showFarmerDetails(mFarmer?.farmerDetail)

        mCollectMilk.setOnClickListener {
            var intent = Intent(this@FarmerDetailActivity, CollectionFormActivity::class.java)
            intent.putExtra(CollectionFormActivity.FARMER_EXTRA, mFarmer)
            startActivity(intent)
            finish()
        }

        mUpdateDetails.setOnClickListener {
            var intent = Intent(this@FarmerDetailActivity, FarmerExtraFormActivity::class.java)
            intent.putExtra(FarmerExtraFormActivity.FARMER_EXTRA, mFarmer)
            startActivityForResult(intent, FARMER_DETAIL_UPDATE_REQUEST_CODE)
        }
        this.initMapFragment()
    }

    private fun initMapFragment() {

        val mapFragment = supportFragmentManager.findFragmentById(R.id.farmer_location) as SupportMapFragment?
        mapFragment!!.getMapAsync { googleMap ->
            mMap = googleMap

            mMap?.mapType = GoogleMap.MAP_TYPE_NORMAL
            // Enable / Disable zooming controls
            mMap?.uiSettings?.isZoomControlsEnabled = false

            // Enable / Disable Compass icon
            mMap?.uiSettings?.isCompassEnabled = true
            // Enable / Disable Rotate gesture
            mMap?.uiSettings?.isRotateGesturesEnabled = true
            // Enable / Disable zooming functionality
            mMap?.uiSettings?.isZoomGesturesEnabled = true

            mMap?.uiSettings?.isScrollGesturesEnabled = true
            mMap?.uiSettings?.isMapToolbarEnabled = true

            mMap?.setMinZoomPreference(14f)

            var supplierLocation = mFarmer?.supplierLocation
            if (supplierLocation != null) {
                var location = LatLng(supplierLocation.latitude!!, supplierLocation.longitude!!)
                mMap?.addMarker(MarkerOptions().position(location))
                mMap?.moveCamera(CameraUpdateFactory.newLatLng(location))
            }
        }
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> {
                false
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FARMER_DETAIL_UPDATE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            var farmerDetail: FarmerDetail? = data?.getSerializableExtra(FarmerExtraFormActivity.FARMER_DETAIL_EXTRA) as FarmerDetail?
            this.showFarmerDetails(farmerDetail)
        } else
            super.onActivityResult(requestCode, resultCode, data)
    }

    private fun showFarmerDetails(farmerDetail: FarmerDetail?) {
        this.mFarmer?.farmerDetail = farmerDetail
        mFarmerLandSize.text = "${if (farmerDetail?.landSize == null) 0.0 else farmerDetail?.landSize} arces"
        mFarmerFeedsType.text = farmerDetail?.feedsType
        mFarmerHerdSize.text = "${if (farmerDetail?.milkingHerdSize == null) 0.0 else farmerDetail?.milkingHerdSize}/" +
                "${if (farmerDetail?.herdSize == null) 0.0 else farmerDetail?.herdSize}"
        mFarmerOtherFormsOfFarming.text = farmerDetail?.otherFarmingForms

    }
}
