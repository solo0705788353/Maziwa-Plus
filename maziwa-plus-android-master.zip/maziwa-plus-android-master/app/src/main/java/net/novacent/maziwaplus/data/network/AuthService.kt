package net.novacent.maziwaplus.data.network

import io.reactivex.Observable
import net.novacent.maziwaplus.data.network.dto.LoginRequest
import net.novacent.maziwaplus.data.network.dto.LoginResponse
import net.novacent.maziwaplus.data.network.dto.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Created by kibichii on 8/25/2018.
 */
interface AuthService {

    @POST("login")
    fun login(@Body loginRequest: LoginRequest?): Observable<LoginResponse>

}