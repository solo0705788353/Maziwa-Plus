package net.novacent.maziwaplus.di.modules

import dagger.Module
import dagger.Provides
import net.novacent.maziwaplus.data.network.*
import retrofit2.Retrofit
import javax.inject.Named

/**
 * Created by kibichii on 8/25/2018.
 */
@Module
class NetworkModule {

    @Provides
    fun provideAuthService(@Named("authRetrofit") retrofit: Retrofit): AuthService = retrofit.create(AuthService::class.java)


    @Provides
    fun provideFarmerService(@Named("retrofit") retrofit: Retrofit): FarmerService = retrofit.create(FarmerService::class.java)


    @Provides
    fun provideUserService(@Named("retrofit") retrofit: Retrofit): UserService = retrofit.create(UserService::class.java)


    @Provides
    fun provideDashboardService(@Named("retrofit") retrofit: Retrofit): DashboardService = retrofit.create(DashboardService::class.java)


    @Provides
    fun provideCollectionService(@Named("retrofit") retrofit: Retrofit): CollectionService = retrofit.create(CollectionService::class.java)

}