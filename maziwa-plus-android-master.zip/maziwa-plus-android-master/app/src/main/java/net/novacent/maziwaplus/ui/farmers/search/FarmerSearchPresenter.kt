package net.novacent.maziwaplus.ui.farmers.search

import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.network.FarmerService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 9/7/2018.
 */
class FarmerSearchPresenter<V : FarmerSearchContract.View>
@Inject constructor(var farmerService: FarmerService, var schedulerProvider: SchedulerProvider, var dataManager: DataManager) : BasePresenter<V>(), FarmerSearchContract.Presenter<V> {

    override fun onSearchClicked() {
        if (view?.validate()!!) {

            view?.toggleProgress(true)
            this.farmerService
                    .findBySupplyNumber(view?.getSearchQuery())
                    .subscribeOn(schedulerProvider.io())
                    .observeOn(schedulerProvider.ui())
                    .subscribe({
                        view?.toggleProgress(false)
                        var farmer = dataManager.deserialize(it.data, Farmer::class.java)
                        view?.onSuccess(farmer)
                    }, {
                        view?.toggleProgress(false)
                        view?.onError(it.message)
                    })
        }
    }


}