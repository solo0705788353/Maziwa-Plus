package net.novacent.maziwaplus.data.models

import java.io.Serializable

/**
 * Created by kibichii on 9/2/2018.
 */
data class Agent(
        var id: Long,
        var uuid: String,
        var active: Boolean
): Serializable