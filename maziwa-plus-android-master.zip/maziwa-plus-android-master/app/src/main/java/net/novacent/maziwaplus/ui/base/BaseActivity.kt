package net.novacent.maziwaplus.ui.base

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.MenuItem
import net.novacent.maziwaplus.MaziwaPlusApplication
import net.novacent.maziwaplus.di.components.ActivityComponent
import net.novacent.maziwaplus.di.components.DaggerActivityComponent
import net.novacent.maziwaplus.di.modules.ActivityModule
import net.novacent.maziwaplus.di.modules.ApplicationModule

/**
 * Created by kibichii on 8/26/2018.
 */
open class BaseActivity : AppCompatActivity() {

    public var activityComponent: ActivityComponent? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        activityComponent = DaggerActivityComponent
                .builder()
                .activityModule(ActivityModule(this))
                .applicationModule(ApplicationModule(application as MaziwaPlusApplication))
                .applicationComponent((application as MaziwaPlusApplication).applicationComponent)
                .build()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }

}