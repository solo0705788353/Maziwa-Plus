package net.novacent.maziwaplus.ui.farmers.search

import android.app.ProgressDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.Toolbar
import android.view.KeyEvent
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import com.basgeekball.awesomevalidation.AwesomeValidation
import com.basgeekball.awesomevalidation.ValidationStyle
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.farmers.detail.FarmerDetailActivity
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormContract
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormPresenter
import javax.inject.Inject

class FarmerSearchActivity : BaseActivity(), FarmerSearchContract.View {


    var mFarmerSearchPresenter: FarmerSearchPresenter<FarmerSearchContract.View>? = null
        @Inject set

    val mValidation: AwesomeValidation = AwesomeValidation(ValidationStyle.UNDERLABEL)

    var mProgressDialog: ProgressDialog? = null

    val mToolbar: Toolbar by bindView(R.id.toolbar)
    val mSearchQuery: AppCompatEditText by bindView(R.id.search_query)

    val mSearchButton: FloatingActionButton by bindView(R.id.search_button)
    val mSearchProgress: ProgressBar by bindView(R.id.search_progress)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_search)

        activityComponent?.inject(this)

        mFarmerSearchPresenter?.attach(this)

        init()
    }

    private fun init() {
        setSupportActionBar(mToolbar)

        if (supportActionBar != null) {
            supportActionBar?.title = "Search Farmers"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
        mProgressDialog = ProgressDialog(this)
        mProgressDialog?.isIndeterminate = true
        mProgressDialog?.setCancelable(false)


        mValidation.addValidation(mSearchQuery, "[a-zA-Z0-9\\s]+", "Input supply number")

        mSearchButton.setOnClickListener {
            mFarmerSearchPresenter?.onSearchClicked()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return super.onOptionsItemSelected(item)
    }

    override fun onSuccess(farmer: Farmer?) {
        mSearchQuery.setText("")
        var intent = Intent(this, FarmerDetailActivity::class.java)
        intent.putExtra(FarmerDetailActivity.FARMER_EXTRA, farmer)
        startActivity(intent)
    }

    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun toggleProgress(show: Boolean) {
        if (show) {
            mProgressDialog?.setMessage("Searching farmer: ${this.getSearchQuery()}")
            mProgressDialog?.show()
        } else {
            mProgressDialog?.dismiss()
        }
        //mSearchProgress.visibility = if (show) View.VISIBLE else View.GONE
        /* if (show) {
             mProgressDialog?.setMessage("Searching farmer...")
             mProgressDialog?.show()
         } else
             mProgressDialog?.dismiss()*/
    }

    override fun validate(): Boolean {
        return mValidation.validate()
    }

    override fun getSearchQuery(): String? {
        return mSearchQuery.text?.toString()
    }

}
