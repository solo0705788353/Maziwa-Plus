package net.novacent.maziwaplus.ui.farmers.form.extra

import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.network.FarmerService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 9/29/2018.
 */
class FarmerExtraFormPresenter<V : FarmerExtraFormContract.View>
@Inject constructor(var farmerService: FarmerService,
                    var schedulerProvider: SchedulerProvider,
                    var dataManager: DataManager)
    : BasePresenter<V>(), FarmerExtraFormContract.Presenter<V> {

    override fun onSaveClicked() {
        if (view?.validate()!!) {

            var farmerDetail = view?.getFarmerDetail()

            view?.toggleProgress(true)
            this.farmerService
                    .createFarmerDetails(farmerDetail, farmerDetail?.farmer?.id)
                    .subscribeOn(schedulerProvider.io())
                    .observeOn(schedulerProvider.ui())
                    .subscribe({
                        view?.toggleProgress(false)
                        view?.onSuccess(farmerDetail)
                    }, {
                        view?.toggleProgress(false)
                        view?.onError(it.message)
                    })

        }
    }
}