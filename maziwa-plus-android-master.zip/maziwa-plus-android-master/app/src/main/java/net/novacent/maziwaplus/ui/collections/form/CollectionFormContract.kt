package net.novacent.maziwaplus.ui.collections.form

import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 8/26/2018.
 */
interface CollectionFormContract {
    interface View : BaseContract.View {
        fun showMilkCollection(milkCollection: MilkCollection?)

        fun getMilkCollection(): MilkCollection

        fun validate(): Boolean

        fun toggleProgress(show: Boolean)

        fun onSuccess(milkCollection: MilkCollection?)

        fun onError(message: String?)

    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onSubmitClicked()
    }
}