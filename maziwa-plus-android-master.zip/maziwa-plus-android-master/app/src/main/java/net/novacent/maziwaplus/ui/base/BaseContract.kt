package net.novacent.maziwaplus.ui.base

/**
 * Created by kibichii on 8/26/2018.
 */
interface BaseContract {
    interface View {

    }

    interface Presenter<V> {
        fun attach(v: V)
    }
}