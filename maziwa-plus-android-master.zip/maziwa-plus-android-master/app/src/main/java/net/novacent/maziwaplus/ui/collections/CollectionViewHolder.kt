package net.novacent.maziwaplus.ui.collections

import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.TextView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.utils.extensions.asString

/**
 * Created by kibichii on 8/16/2018.
 */
class CollectionViewHolder(var view: View) : RecyclerView.ViewHolder(view) {
    var mFarmerName: TextView
    var mDate: TextView
    var mCollectionQuantity: AppCompatButton

    init {
        mFarmerName = view.findViewById(R.id.farmer_name)
        mCollectionQuantity = view.findViewById(R.id.collection_quantity)
        mDate = view.findViewById(R.id.collection_date)
    }

    fun bind(milkCollection: MilkCollection) {
        mFarmerName.text = milkCollection.supplier?.getFullName()
        mCollectionQuantity.text = "${milkCollection.weight} Kgs"
        mDate.text = milkCollection.createdAt?.asString("dd-MM-yyyy")
    }
}