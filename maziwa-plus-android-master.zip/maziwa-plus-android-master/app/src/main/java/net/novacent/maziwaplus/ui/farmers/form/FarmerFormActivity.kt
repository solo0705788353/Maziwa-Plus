package net.novacent.maziwaplus.ui.farmers.form

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.basgeekball.awesomevalidation.AwesomeValidation
import com.basgeekball.awesomevalidation.ValidationStyle
import com.schibstedspain.leku.LATITUDE
import com.schibstedspain.leku.LOCATION_ADDRESS
import com.schibstedspain.leku.LONGITUDE
import com.schibstedspain.leku.LocationPickerActivity
import com.shagi.materialdatepicker.date.DatePickerFragmentDialog
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.FarmerLocation
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.farmers.detail.FarmerDetailActivity
import net.novacent.maziwaplus.ui.farmers.form.location.FarmerLocationPickerActivity
import net.novacent.maziwaplus.utils.extensions.asString
import net.novacent.maziwaplus.utils.extensions.tryToDate
import java.util.*
import javax.inject.Inject

class FarmerFormActivity : BaseActivity(), FarmerFormContract.View {

    companion object {
        private var LOCATION_REQUEST_CODE: Int = 200
    }

    val mToolbar: Toolbar by bindView(R.id.toolbar)

    val mFarmerSurname: AppCompatEditText by bindView(R.id.form_surname)
    val mFarmerOtherNames: AppCompatEditText by bindView(R.id.form_other_names)
    val mFarmerPhoneNumber: AppCompatEditText by bindView(R.id.form_phone_number)
    val mFarmerIdNumber: AppCompatEditText by bindView(R.id.form_id_number)
    val mFarmerDateOfBirth: AppCompatEditText by bindView(R.id.form_date_of_birth)
    val mFarmerSupplyNumber: AppCompatEditText by bindView(R.id.form_supply_number)

    val mSelectDateOfBirth: LinearLayout by bindView(R.id.select_date_of_birth)

    val mSubmit: AppCompatButton by bindView(R.id.form_submit)

    val mSelectLocation: LinearLayout by bindView(R.id.select_location)
    val mLocationSelected: TextView by bindView(R.id.location_status)

    val mValidation: AwesomeValidation = AwesomeValidation(ValidationStyle.UNDERLABEL)

    var mFarmerFormPresenter: FarmerFormPresenter<FarmerFormContract.View>? = null
        @Inject set

    var mProgressDialog: ProgressDialog? = null


    var mFarmerLocation: FarmerLocation? = null

    private var mFarmer: Farmer? = Farmer()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_form)
        mValidation.setContext(this)
        activityComponent?.inject(this)

        mFarmerFormPresenter?.attach(this)

        mValidation.setContext(this)
        setSupportActionBar(mToolbar)

        if (supportActionBar != null) {
            supportActionBar?.title = "Add Farmer"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        init()
    }

    private fun init() {
        mValidation.addValidation(mFarmerSurname, "[a-zA-Z\\s]+", "Input Surname")
        mValidation.addValidation(mFarmerIdNumber, "[0-9]+", "Input Id Number")
        mValidation.addValidation(mFarmerPhoneNumber, "07[0-9]{8}", "Input a valid Phone Number")
        mValidation.addValidation(mFarmerSupplyNumber, "[a-zA-Z0-9\\s]+", "Input Supply Number")
        // mValidation.addValidation(mFarmerDateOfBirth, "[0-9]{2}-[0-9]{2}-[0-9]{4}", "Enter date of birth")

        // mFarmerDateOfBirth.isEnabled = false
        mSelectDateOfBirth.setOnClickListener {
            val dialog = DatePickerFragmentDialog.newInstance({ view, year, monthOfYear, dayOfMonth ->
                var calendar = Calendar.getInstance()
                calendar.set(year, monthOfYear, dayOfMonth)

                var date = calendar.time
                mFarmerDateOfBirth.setText(date.asString("dd-MM-yyyy"))
            })
            dialog.show(supportFragmentManager, "dateOfBirthPickerFragment")
        }


/*        mFarmerDateOfBirth.setOnClickListener {
            val dialog = DatePickerFragmentDialog.newInstance({ view, year, monthOfYear, dayOfMonth ->
                var date = Date(year, monthOfYear, dayOfMonth)
                (it as AppCompatEditText).setText(date.asString())
            })
            dialog.show(supportFragmentManager, "dateOfBirthPickerFragment")
        }*/

        mProgressDialog = ProgressDialog(this)
        mProgressDialog?.isIndeterminate = true
        mProgressDialog?.setMessage("Registering Farmer...")
        mProgressDialog?.setCancelable(false)

        mSubmit.setOnClickListener {
            mFarmerFormPresenter?.onSubmitClicked()
        }

        mSelectLocation.setOnClickListener {
            /*       var intent = Intent(this@FarmerFormActivity, FarmerLocationPickerActivity::class.java)
                   startActivityForResult(intent, LOCATION_REQUEST_CODE)*/
            val locationPickerIntent = LocationPickerActivity.Builder()
                    // .withLocation(41.4036299, 2.1743558)
                    .withGeolocApiKey("AIzaSyDWZJhcb8UPSefpRRYeTjrXy5XFKGVPeww")
                    // .withSearchZone("es_ES")
                    .shouldReturnOkOnBackPressed()
                    //.withStreetHidden()
                    //.withCityHidden()
                    .withZipCodeHidden()
                    .withSatelliteViewHidden()
                    .withGooglePlacesEnabled()
                    //.withGoogleTimeZoneEnabled()
                    .withVoiceSearchHidden()
                    .build(applicationContext)

            startActivityForResult(locationPickerIntent, LOCATION_REQUEST_CODE)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == LOCATION_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            /*  this.mFarmerLocation = data?.getSerializableExtra("LOCATION_EXTRA") as FarmerLocation?
              this.mLocationSelected.text = "Location selected"*/

            val latitude = data?.getDoubleExtra(LATITUDE, 0.0)
            val longitude = data?.getDoubleExtra(LONGITUDE, 0.0)
            val address = data?.getStringExtra(LOCATION_ADDRESS)

            var farmerLocation = FarmerLocation(
                    latitude = latitude,
                    longitude = longitude,
                    label = address,
                    accuracy = 0.0
            )
            this.mFarmerLocation = farmerLocation
            this.mLocationSelected.text = address
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> {
                super.onOptionsItemSelected(item)
            }
        }
    }

    override fun getFarmer(): Farmer? {
        var farmer = Farmer(
                surname = mFarmerSurname.text.toString(),
                otherNames = mFarmerOtherNames.text.toString(),
                idNumber = mFarmerIdNumber.text.toString(),
                phoneNumber = mFarmerPhoneNumber.text.toString(),
                dateOfBirth = mFarmerDateOfBirth.text.toString().tryToDate(),
                supplierLocation = mFarmerLocation,
                supplyNumber = mFarmerSupplyNumber.text.toString()
        )
        farmer.id = mFarmer?.id
        return farmer
    }


    override fun showFarmer(farmer: Farmer?) {
        this.mFarmer = farmer

        mFarmerSurname.setText(farmer?.surname)
        mFarmerOtherNames.setText(farmer?.otherNames)
        mFarmerIdNumber.setText(farmer?.idNumber)
        mFarmerSupplyNumber.setText(farmer?.supplyNumber)
        mFarmerPhoneNumber.setText(farmer?.phoneNumber)
        mFarmerDateOfBirth.setText(farmer?.dateOfBirth?.asString())
    }

    override fun toggleProgress(show: Boolean) {
        if (show)
            mProgressDialog?.show()
        else
            mProgressDialog?.dismiss()

    }

    override fun validate(): Boolean {
        return mValidation.validate()
    }

    override fun onSuccess(farmer: Farmer?) {
        Toast.makeText(this, "Farmer registered", Toast.LENGTH_LONG).show()
        var intent = Intent(this@FarmerFormActivity, FarmerDetailActivity::class.java)
        intent.putExtra(FarmerDetailActivity.FARMER_EXTRA, farmer)
        startActivity(intent)
        finish()
    }

    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    }
}
