package net.novacent.maziwaplus.ui.collections.form

import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.data.network.CollectionService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 8/26/2018.
 */
class CollectionFormPresenter<V : CollectionFormContract.View>
@Inject constructor(var collectionService: CollectionService,
                    var schedulerProvider: SchedulerProvider,
                    var dataManager: DataManager)
    : BasePresenter<V>(), CollectionFormContract.Presenter<V> {

    override fun onSubmitClicked() {
        if (view?.validate()!!) {
            var milkCollection: MilkCollection? = view?.getMilkCollection()

            view?.toggleProgress(true)

            this.collectionService
                    .create(milkCollection)
                    .subscribeOn(schedulerProvider.io())
                    .observeOn(schedulerProvider.ui())
                    .subscribe({
                        var milkCollection: MilkCollection = dataManager.deserialize(it.data, MilkCollection::class.java)
                        view?.onSuccess(milkCollection)
                        view?.toggleProgress(false)
                    }, {
                        view?.toggleProgress(false)
                        view?.onError(it.message)
                    })

        }
    }
}