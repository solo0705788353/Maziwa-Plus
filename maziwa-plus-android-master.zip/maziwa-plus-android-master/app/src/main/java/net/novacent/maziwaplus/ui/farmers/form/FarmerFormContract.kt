package net.novacent.maziwaplus.ui.farmers.form

import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 8/26/2018.
 */
interface FarmerFormContract {
    interface View : BaseContract.View {
        fun getFarmer(): Farmer?

        fun showFarmer(farmer: Farmer?)

        fun toggleProgress(show: Boolean)

        fun validate(): Boolean

        fun onSuccess(farmer: Farmer?)

        fun onError(message: String?)
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onSubmitClicked()

    }
}