package net.novacent.maziwaplus.ui.base

/**
 * Created by kibichii on 8/26/2018.
 */
open class BasePresenter<V : BaseContract.View> : BaseContract.Presenter<V> {
    public var view: V? = null

    override fun attach(v: V) {
        this.view = v
    }
}