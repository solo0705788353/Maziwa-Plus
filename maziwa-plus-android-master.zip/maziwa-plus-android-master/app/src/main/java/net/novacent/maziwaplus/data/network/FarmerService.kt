package net.novacent.maziwaplus.data.network

import io.reactivex.Observable
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.FarmerDetail
import net.novacent.maziwaplus.data.network.dto.Response
import retrofit2.http.*

/**
 * Created by kibichii on 8/25/2018.
 */
interface FarmerService {

    @POST("suppliers")
    fun createFarmer(@Body farmer: Farmer?): Observable<Response>

    @GET("suppliers")
    fun fetchFarmers(): Observable<Response>

    @GET("suppliers/find")
    fun searchFarmers(@Query("query") query: String): Observable<Response>

    @GET("suppliers/supply-number/{supplyNumber}")
    fun findBySupplyNumber(@Path("supplyNumber") supplyNumber: String?): Observable<Response>

    @POST("suppliers/{id}/farmer-details")
    fun createFarmerDetails(@Body farmerDetail: FarmerDetail?, @Path("id") id: Long?): Observable<Response>

    @PUT("suppliers/{id}/farmer-details")
    fun updateFarmerDetails(@Body farmerDetail: FarmerDetail?, @Path("id") id: Long?): Observable<Response>

}