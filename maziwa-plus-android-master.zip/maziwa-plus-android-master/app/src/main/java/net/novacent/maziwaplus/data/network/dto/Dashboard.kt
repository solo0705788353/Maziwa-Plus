package net.novacent.maziwaplus.data.network.dto

import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.MilkCollection
import java.io.Serializable

/**
 * Created by kibichii on 9/5/2018.
 */
class Dashboard : Serializable {
    var collectionsCount: Long = 0L

    var suppliersCount: Long = 0L

    var latestCollections: List<MilkCollection> = mutableListOf()

    var latestRegistrations: List<Farmer> = mutableListOf()
}