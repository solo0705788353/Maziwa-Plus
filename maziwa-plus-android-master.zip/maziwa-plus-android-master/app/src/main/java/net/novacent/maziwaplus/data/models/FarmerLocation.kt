package net.novacent.maziwaplus.data.models

import java.io.Serializable

/**
 * Created by kibichii on 8/25/2018.
 */
data class FarmerLocation(
        var uuid: String? = "",
        var id: Long? = 0,
        var latitude: Double? = 0.0,
        var longitude: Double? = 0.0,
        var accuracy: Double? = 0.0,
        var label: String? = "",
        var active: Boolean? = true
) : Serializable