package net.novacent.maziwaplus.ui.farmers

import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.network.FarmerService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 9/3/2018.
 */
class FarmersPresenter<V : FarmersContract.View> @Inject constructor(
        var farmerService: FarmerService,
        var schedulerProvider: SchedulerProvider,
        var dataManager: DataManager
) : BasePresenter<V>(), FarmersContract.Presenter<V> {

    override fun fetchFarmers() {
        view?.toggleProgress(true)
        farmerService.fetchFarmers()
                .subscribeOn(schedulerProvider.io())
                .observeOn(schedulerProvider.ui())
                .subscribe({
                    view?.toggleProgress(false)
                    var data = dataManager.deserialize(it.data, List::class.java)
                    var farmers: MutableList<Farmer> = mutableListOf()
                    for (o: Any? in data) {
                        farmers.add(dataManager.deserialize(o, Farmer::class.java))
                    }
                    view?.onSuccess(farmers)
                }, {
                    view?.toggleProgress(false)

                })
    }
}