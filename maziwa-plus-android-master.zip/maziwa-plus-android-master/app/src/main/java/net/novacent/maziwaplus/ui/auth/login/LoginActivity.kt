package net.novacent.maziwaplus.ui.auth.login

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.v7.widget.AppCompatEditText
import android.widget.Button
import android.widget.Toast
import com.basgeekball.awesomevalidation.AwesomeValidation
import com.basgeekball.awesomevalidation.ValidationStyle
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.User
import net.novacent.maziwaplus.data.network.dto.LoginRequest
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.main.MainActivity
import javax.inject.Inject

class LoginActivity : BaseActivity(), LoginContract.View {

    val mLoginButton: Button by bindView(R.id.login_button)

    var mLoginPresenter: LoginPresenter<LoginContract.View>? = null
        @Inject set

    var mDataManager: DataManager? = null
        @Inject set

    val mLoginUsername: AppCompatEditText by bindView(R.id.login_username)
    val mLoginPassword: AppCompatEditText by bindView(R.id.login_password)

    val mValidation: AwesomeValidation = AwesomeValidation(ValidationStyle.UNDERLABEL)

    var mProgressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        activityComponent?.inject(this)

        mLoginPresenter?.attach(this)

        mLoginButton.setOnClickListener {
            mLoginPresenter?.onLoginClicked()
        }

        if (mDataManager?.loggedIn!!) {
            var intent = Intent(this@LoginActivity, MainActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        init()
    }

    private fun init() {
        mValidation.setContext(this)
        mValidation.addValidation(mLoginUsername, "[A-Za-z\\s]+", "Enter username")
        mValidation.addValidation(mLoginPassword, "[A-Za-z\\s]+", "Enter password")

        mProgressDialog = ProgressDialog(this)
        mProgressDialog?.isIndeterminate = true
        mProgressDialog?.setMessage("Authenticating...")
        mProgressDialog?.setCancelable(false)

    }

    override fun getCredentials(): LoginRequest {
        return LoginRequest(
                username = mLoginUsername.text?.toString(),
                password = mLoginPassword.text?.toString()
        )
    }

    override fun validate(): Boolean {
        return mValidation.validate()
    }

    override fun toggleProgress(show: Boolean) {
        if (show) {
            mProgressDialog?.show()
        } else {
            mProgressDialog?.dismiss()
        }
    }

    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onSuccess(user: User?) {
        var intent = Intent(this@LoginActivity, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}
