package net.novacent.maziwaplus.di.modules

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import net.novacent.maziwaplus.utils.network.RxErrorHandlingCallAdapterFactory
import net.novacent.maziwaplus.utils.scheduler.AppSchedulerProvider
import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import dagger.Module
import dagger.Provides
import net.novacent.maziwaplus.MaziwaPlusApplication
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.AppDataManager
import net.novacent.maziwaplus.data.DataManager
import okhttp3.Cache
import okhttp3.OkHttpClient
import retrofit2.CallAdapter
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Named


/**
 * Created by KEVIN on 12/13/2017.
 */

@Module(includes = [NetworkModule::class])
class ApplicationModule(private val maziwaPlusApplication: MaziwaPlusApplication) {
    @Provides
    fun provideMaziwaPlusApplication() = maziwaPlusApplication

    @Provides
    fun provideSchedulerProvider(): SchedulerProvider =
            AppSchedulerProvider

    @Provides
    fun provideGson(): Gson =
            GsonBuilder()
                    .setLenient()
                    .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                    .setDateFormat("yyyy-MM-dd HH:mm:ss")
                    .serializeNulls()
                    .setPrettyPrinting()
                    .create()


    @Provides
    fun gsonConverterFactory(gson: Gson): GsonConverterFactory =
            GsonConverterFactory.create(gson)

    @Provides
    @Named("authOkHttpClient")
    fun provideAuthOkHttpClient(): OkHttpClient =
            OkHttpClient.Builder()
                    .addInterceptor { chain ->
                        val request = chain
                                .request().newBuilder()
                                .build()
                        Log.e("URL:", chain.request().url().host())
                        chain.proceed(request)
                    }
                    .build()

    @Provides
    fun provideCache(context: Context): Cache {
        return Cache(context.cacheDir, (10 * 1024 * 1024))
    }

    @Provides
    @Named("okHttpClient")
    fun provideOkHttpClient(dataManager: DataManager, cache: Cache): OkHttpClient {
        return OkHttpClient.Builder()
                .cache(cache)
                .addInterceptor { chain ->
                    val request = chain
                            .request().newBuilder()
                            ?.addHeader("Authorization", "Bearer ${dataManager.apiToken}")
                            ?.addHeader("Accept", "application/json")
                            ?.build()

                    chain.proceed(request)

                }
                .addInterceptor { chain ->
                    val request = chain.request()?.newBuilder()?.build()
                    Log.d("URL:", request?.url()?.toString())
                    chain.proceed(request)
                }
                .build()
    }

    @Provides
    @Named("callAdapterFactory")
    fun provideCallAdapterFactory(): CallAdapter.Factory =
            RxErrorHandlingCallAdapterFactory.create()


    @Provides
    fun provideBaseUrl(context: Context): String {
        return context.resources.getString(R.string.base_api_url)
    }


    @Provides
    @Named("authRetrofit")
    fun provideAuthRetrofit(gsonConverterFactory: GsonConverterFactory,
                            @Named("callAdapterFactory") callAdapterFactory: CallAdapter.Factory, baseUrl: String, @Named("authOkHttpClient") authOkHttpClient: OkHttpClient):
            Retrofit = Retrofit.Builder()
            .addConverterFactory(gsonConverterFactory)
            .addCallAdapterFactory(callAdapterFactory)
            .client(authOkHttpClient)
            .baseUrl(baseUrl)
            .build()

    @Provides
    @Named("retrofit")
    fun provideRetrofit(gsonConverterFactory: GsonConverterFactory,
                        @Named("callAdapterFactory") callAdapterFactory: CallAdapter.Factory, baseUrl: String, @Named("okHttpClient") okHttpClient: OkHttpClient): Retrofit = Retrofit.Builder()
            .addConverterFactory(gsonConverterFactory)
            .addCallAdapterFactory(callAdapterFactory)
            .client(okHttpClient)
            .baseUrl(baseUrl)
            .build()

    @Provides
    fun provideSharedPreferences(context: Context): SharedPreferences =
            context.getSharedPreferences(MaziwaPlusApplication.SHARED_PREFS_FILE, Context.MODE_PRIVATE)

    @Provides
    fun provideDataManager(sharedPreferences: SharedPreferences, gson: Gson): DataManager =
            AppDataManager(sharedPreferences, gson)

}