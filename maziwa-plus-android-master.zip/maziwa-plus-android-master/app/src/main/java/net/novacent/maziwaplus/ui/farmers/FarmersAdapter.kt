package net.novacent.maziwaplus.ui.farmers

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer

/**
 * Created by kibichii on 8/16/2018.
 */
class FarmersAdapter(var mContext: Context, var farmers: List<Farmer>, var mItemListener: FarmersContract.Item) : RecyclerView.Adapter<FarmerViewHolder>() {
    var mLayoutInflater: LayoutInflater

    init {
        mLayoutInflater = LayoutInflater.from(mContext)
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): FarmerViewHolder {
        var view = mLayoutInflater.inflate(R.layout.item_farmer, p0, false)

        return FarmerViewHolder(view)
    }

    override fun onBindViewHolder(p0: FarmerViewHolder, p1: Int) {
        var farmer = farmers[p1]
        p0.view.setOnClickListener {
            mItemListener.itemClicked(farmer = farmer)
        }
        p0.bind(farmer = farmer)
    }

    override fun getItemCount(): Int {
        return farmers.size
    }
}