package net.novacent.maziwaplus.data.network.dto

/**
 * Created by kibichii on 9/2/2018.
 */
data class LoginResponse(
        var token: String
)