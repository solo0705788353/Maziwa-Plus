package net.novacent.maziwaplus.data.network

import io.reactivex.Observable
import net.novacent.maziwaplus.data.network.dto.Response
import retrofit2.http.GET

/**
 * Created by kibichii on 9/5/2018.
 */
interface DashboardService {
    @GET("dashboard")
    fun fetchDashboard(): Observable<Response>
}