package net.novacent.maziwaplus.ui.farmers.search

import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 9/7/2018.
 */
interface FarmerSearchContract {
    interface View : BaseContract.View {
        fun onSuccess(farmer: Farmer?)

        fun onError(message: String?)

        fun toggleProgress(show: Boolean)

        fun validate(): Boolean

        fun getSearchQuery(): String?
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onSearchClicked()
    }
}