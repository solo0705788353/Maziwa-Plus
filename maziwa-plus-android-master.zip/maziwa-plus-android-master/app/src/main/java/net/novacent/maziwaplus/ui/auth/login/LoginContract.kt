package net.novacent.maziwaplus.ui.auth.login

import net.novacent.maziwaplus.data.models.User
import net.novacent.maziwaplus.data.network.dto.LoginRequest
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 9/2/2018.
 */
interface LoginContract {
    interface View : BaseContract.View {

        fun getCredentials(): LoginRequest

        fun validate(): Boolean

        fun toggleProgress(show: Boolean)

        fun onError(message: String?)

        fun onSuccess(user: User?)
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onLoginClicked()

    }
}