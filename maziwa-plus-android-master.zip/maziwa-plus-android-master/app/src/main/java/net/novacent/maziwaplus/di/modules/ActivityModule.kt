package net.novacent.maziwaplus.di.modules

import android.content.Context
import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import dagger.Module
import dagger.Provides
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.network.*
import net.novacent.maziwaplus.ui.auth.login.LoginContract
import net.novacent.maziwaplus.ui.auth.login.LoginPresenter
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.collections.form.CollectionFormContract
import net.novacent.maziwaplus.ui.collections.form.CollectionFormPresenter
import net.novacent.maziwaplus.ui.farmers.FarmersContract
import net.novacent.maziwaplus.ui.farmers.FarmersPresenter
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormContract
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormPresenter
import net.novacent.maziwaplus.ui.farmers.form.extra.FarmerExtraFormContract
import net.novacent.maziwaplus.ui.farmers.form.extra.FarmerExtraFormPresenter
import net.novacent.maziwaplus.ui.farmers.search.FarmerSearchContract
import net.novacent.maziwaplus.ui.farmers.search.FarmerSearchPresenter
import net.novacent.maziwaplus.ui.main.MainContract
import net.novacent.maziwaplus.ui.main.MainPresenter

/**
 * Created by kibichii on 8/25/2018.
 */
@Module
class ActivityModule(val baseActivity: BaseActivity) {
    @Provides
    fun provideContext(): Context {
        return baseActivity
    }

    @Provides
    fun provideCollectionLoginPresenter(authService: AuthService, userService: UserService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            LoginPresenter<LoginContract.View> {
        return LoginPresenter(schedulerProvider = schedulerProvider, authService = authService, userService = userService, dataManager = dataManager)
    }

    @Provides
    fun provideFarmerFormPresenter(farmerService: FarmerService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            FarmerFormPresenter<FarmerFormContract.View> {
        return FarmerFormPresenter(schedulerProvider = schedulerProvider, farmerService = farmerService, dataManager = dataManager)
    }

    @Provides
    fun provideCollectionFormPresenter(collectionService: CollectionService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            CollectionFormPresenter<CollectionFormContract.View> {
        return CollectionFormPresenter(schedulerProvider = schedulerProvider, collectionService = collectionService, dataManager = dataManager)
    }

    @Provides
    fun provideFarmersPresenter(farmerService: FarmerService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            FarmersPresenter<FarmersContract.View> {
        return FarmersPresenter(schedulerProvider = schedulerProvider, farmerService = farmerService, dataManager = dataManager)
    }

    @Provides
    fun provideMainPresenter(dashboardService: DashboardService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            MainPresenter<MainContract.View> {
        return MainPresenter(schedulerProvider = schedulerProvider, dashboardService = dashboardService, dataManager = dataManager)
    }

    @Provides
    fun provideFarmerSearchPresenter(farmerService: FarmerService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            FarmerSearchPresenter<FarmerSearchContract.View> {
        return FarmerSearchPresenter(schedulerProvider = schedulerProvider, farmerService = farmerService, dataManager = dataManager)
    }

    @Provides
    fun provideFarmerExtraFormPresenter(farmerService: FarmerService, schedulerProvider: SchedulerProvider, dataManager: DataManager):
            FarmerExtraFormPresenter<FarmerExtraFormContract.View> {
        return FarmerExtraFormPresenter(schedulerProvider = schedulerProvider, farmerService = farmerService, dataManager = dataManager)
    }
}