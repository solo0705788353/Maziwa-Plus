package net.novacent.maziwaplus.ui.farmers

import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer

/**
 * Created by kibichii on 8/16/2018.
 */
class FarmerViewHolder(var view: View) : RecyclerView.ViewHolder(view) {
    var mFarmerName: TextView
    var mFarmerSupplyNumber: TextView
    var mFarmerAvatar: ImageView? = null

    init {
        mFarmerName = view.findViewById(R.id.farmer_name)
        mFarmerSupplyNumber = view.findViewById(R.id.farmer_supply_number)
    }

    fun bind(farmer: Farmer) {
        this.mFarmerName.text = "${farmer.surname} ${farmer.otherNames}"
        this.mFarmerSupplyNumber.text = farmer.supplyNumber
    }
}