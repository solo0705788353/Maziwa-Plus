package net.novacent.maziwaplus

import android.app.Application
import android.support.multidex.MultiDexApplication
import net.novacent.maziwaplus.di.components.ApplicationComponent
import net.novacent.maziwaplus.di.components.DaggerApplicationComponent
import net.novacent.maziwaplus.di.modules.ApplicationModule

/**
 * Created by kibichii on 8/11/2018.
 */
class MaziwaPlusApplication : MultiDexApplication() {

    companion object {
        val SHARED_PREFS_FILE: String? = "com.turnkeyafrica.team.prefs"

        object SharedPreferencesKeys {
            public val EMPLOYEE: String = "employee"

            public val USER: String = "user"

            public val API_TOKEN: String = "api_token"

            public val LOGGED_IN: String = "logged_in"

            val DEVICE_TOKEN: String = "device_token"

            val DEVICE_TOKEN_SENT: String = "device_token_sent"
        }

    }

    override fun onCreate() {
        super.onCreate()
    }

    val applicationComponent: ApplicationComponent by lazy {
        DaggerApplicationComponent
                .builder()
                .applicationModule(ApplicationModule(this))
                .build()
    }
}