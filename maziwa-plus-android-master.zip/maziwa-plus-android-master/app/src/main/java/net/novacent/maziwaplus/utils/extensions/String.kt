package net.novacent.maziwaplus.utils.extensions

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by kibichii on 8/26/2018.
 */
fun String.tryToDate(): Date? {
    return tryToDate("dd-MM-yyyy")
}

fun String.tryToDate(format: String): Date? {
    return try {
        SimpleDateFormat(format, Locale.US).parse(this)
    } catch (e: ParseException) {
        null
    }
}