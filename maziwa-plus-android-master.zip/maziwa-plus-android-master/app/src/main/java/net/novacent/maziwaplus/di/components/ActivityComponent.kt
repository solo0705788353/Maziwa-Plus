package net.novacent.maziwaplus.di.components

import dagger.Component
import net.novacent.maziwaplus.di.modules.ActivityModule
import net.novacent.maziwaplus.di.modules.ApplicationModule
import net.novacent.maziwaplus.ui.auth.login.LoginActivity
import net.novacent.maziwaplus.ui.collections.form.CollectionFormActivity
import net.novacent.maziwaplus.ui.farmers.FarmersActivity
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormActivity
import net.novacent.maziwaplus.ui.farmers.form.extra.FarmerExtraFormActivity
import net.novacent.maziwaplus.ui.farmers.search.FarmerSearchActivity
import net.novacent.maziwaplus.ui.main.MainActivity

/**
 * Created by kibichii on 8/25/2018.
 */
@Component(modules = [ApplicationModule::class, ActivityModule::class], dependencies = [ApplicationComponent::class])
interface ActivityComponent {

    fun inject(farmerFormActivity: FarmerFormActivity)

    fun inject(collectionFormActivity: CollectionFormActivity)

    fun inject(loginActivity: LoginActivity)

    fun inject(farmersActivity: FarmersActivity)

    fun inject(mainActivity: MainActivity)

    fun inject(farmerSearchActivity: FarmerSearchActivity)

    fun inject(farmerExtraFormActivity: FarmerExtraFormActivity)

}