package net.novacent.maziwaplus.ui.auth.login

import android.util.Log
import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.User
import net.novacent.maziwaplus.data.network.AuthService
import net.novacent.maziwaplus.data.network.UserService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 9/2/2018.
 */
class LoginPresenter<V : LoginContract.View> @Inject constructor(
        var authService: AuthService,
        var userService: UserService,
        var dataManager: DataManager,
        var schedulerProvider: SchedulerProvider
) : BasePresenter<V>(), LoginContract.Presenter<V> {

    override fun onLoginClicked() {
        if (view?.validate()!!) {
            view?.toggleProgress(true)
            var loginRequest = view?.getCredentials()
            this.authService
                    .login(loginRequest)
                    .subscribeOn(schedulerProvider.io())
                    .observeOn(schedulerProvider.ui())
                    .subscribe({
                        Log.e("Token: ", it.token)
                        dataManager.loggedIn = true
                        dataManager.apiToken = it.token
                        userService.userProfile()
                                .subscribeOn(schedulerProvider.io())
                                .observeOn(schedulerProvider.ui())
                                .subscribe({
                                    var user = dataManager.deserialize(it.data, User::class.java)
                                    dataManager.user = user
                                    view?.toggleProgress(false)
                                    view?.onSuccess(user)
                                }, {
                                    view?.toggleProgress(false)
                                    view?.onError(it.message)
                                }
                                )
                    }, {
                        it.printStackTrace()
                        view?.toggleProgress(false)
                        view?.onError(it.message)
                    })
        }
    }


}