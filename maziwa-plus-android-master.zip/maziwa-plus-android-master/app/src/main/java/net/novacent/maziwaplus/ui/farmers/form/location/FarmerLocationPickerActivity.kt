package net.novacent.maziwaplus.ui.farmers.form.location

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.support.design.widget.BottomSheetBehavior
import android.support.design.widget.FloatingActionButton
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.ResultCallback
import com.google.android.gms.location.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.karumi.dexter.listener.single.PermissionListener
import kotterknife.bindView
import net.novacent.maziwaplus.data.models.FarmerLocation
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.R


class FarmerLocationPickerActivity : BaseActivity(),
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener, GoogleMap.OnMyLocationButtonClickListener {

    override fun onMyLocationButtonClick(): Boolean {
        return true
    }


    val mSelectLocation: FloatingActionButton by bindView(R.id.fab_select_location)
    val mLocationName: TextView by bindView(R.id.location_name)
    val mLocationAccuracy: TextView by bindView(R.id.location_accuracy)

    val mToolbar: Toolbar by bindView(R.id.toolbar)
    val mBottomSheet: LinearLayout by bindView(R.id.bottom_sheet)

    private var mMap: GoogleMap? = null
    private var bottomSheetBehavior: BottomSheetBehavior<*>? = null

    private var mLocationManager: LocationManager? = null

    var mLocationRequest: LocationRequest? = null
    var googleApiClient: GoogleApiClient? = null

    var mSelectedLocation: Location? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_location_picker)

        init()
        initComponent()
        initGoogleApiClient()

    }

    private fun init() {
        setSupportActionBar(mToolbar)
        if (supportActionBar != null) {
            supportActionBar?.title = "Select Location"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        Dexter.withActivity(this)
                .withPermissions(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                .withListener(object : MultiplePermissionsListener {
                    override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                        if (report?.areAllPermissionsGranted()!!) {
                            initMapFragment()
                        } else {
                            Toast.makeText(this@FarmerLocationPickerActivity, "We'll need this permission to access the location.", Toast.LENGTH_LONG).show()

                        }
                    }

                    override fun onPermissionRationaleShouldBeShown(permissions: MutableList<PermissionRequest>?, token: PermissionToken?) {

                    }

                }).withErrorListener {

                }.check()
    }

    private fun initComponent() {
        // init the bottom sheet behavior
      /*  bottomSheetBehavior = BottomSheetBehavior.from(mBottomSheet)

        // change the state of the bottom sheet
        bottomSheetBehavior?.state = BottomSheetBehavior.STATE_COLLAPSED

        // set callback for changes
        bottomSheetBehavior?.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
            override fun onStateChanged(bottomSheet: View, newState: Int) {

            }

            override fun onSlide(bottomSheet: View, slideOffset: Float) {

            }
        })
*/
        mSelectLocation.setOnClickListener {
            // bottomSheetBehavior?.setState(BottomSheetBehavior.STATE_COLLAPSED)
            /* try {
                 mMap?.animateCamera(zoomingLocation())
             } catch (e: Exception) {
             }*/
            if (mSelectedLocation != null) {
                var mFarmerLocation = FarmerLocation(
                        latitude = mSelectedLocation?.latitude,
                        longitude = mSelectedLocation?.longitude,
                        label = mSelectedLocation?.accuracy?.toString()
                )

                var data = Intent()
                data.putExtra("LOCATION_EXTRA", mFarmerLocation)
                setResult(Activity.RESULT_OK, data)
                finish()
            }
        }
    }

    private fun initMapFragment() {

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment!!.getMapAsync { googleMap ->
            mMap = googleMap

            mMap?.mapType = GoogleMap.MAP_TYPE_NORMAL
            // Enable / Disable zooming controls
            mMap?.uiSettings?.isZoomControlsEnabled = false

            // Enable / Disable Compass icon
            mMap?.uiSettings?.isCompassEnabled = true
            // Enable / Disable Rotate gesture
            mMap?.uiSettings?.isRotateGesturesEnabled = true
            // Enable / Disable zooming functionality
            mMap?.uiSettings?.isZoomGesturesEnabled = true

            mMap?.uiSettings?.isScrollGesturesEnabled = true
            mMap?.uiSettings?.isMapToolbarEnabled = true

            mMap?.setMyLocationEnabled(true)

            updateCurrentLocation(this.currentLocation())

            mMap?.setOnMyLocationButtonClickListener(this)

        }
    }

    private fun updateCurrentLocation(location: Location?) {
        this.mSelectedLocation = location
        if (mSelectedLocation != null) {
            val markerOptions = MarkerOptions().position(LatLng(mSelectedLocation?.latitude!!, mSelectedLocation?.latitude!!))
                    .title("Current location")

            markerOptions.icon(BitmapDescriptorFactory
                    .defaultMarker(BitmapDescriptorFactory.HUE_ROSE))

            mMap?.addMarker(markerOptions)
            mMap?.moveCamera(zoomingLocation())
            mMap?.setOnMarkerClickListener({
                bottomSheetBehavior?.state = BottomSheetBehavior.STATE_COLLAPSED
                try {
                    mMap?.animateCamera(zoomingLocation())
                } catch (e: Exception) {
                }

                true
            })
        }
    }

    private fun currentLocation(): Location? {
        var locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        var criteria = Criteria()

        var provider = locationManager.getBestProvider(criteria, true)
        var location = locationManager.getLastKnownLocation(provider)

        return location

    }

    private fun zoomingLocation(): CameraUpdate {
        if (mSelectedLocation == null) {
            mSelectedLocation = LocationServices.FusedLocationApi.getLastLocation(googleApiClient)
        }
        return CameraUpdateFactory.newLatLngZoom(LatLng(mSelectedLocation?.latitude!!, mSelectedLocation?.longitude!!), 13f)
    }

    fun initGoogleApiClient(): GoogleApiClient? {

        if (googleApiClient == null) {
            googleApiClient = GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build()
        }

        return googleApiClient
    }

    override fun onConnected(p0: Bundle?) {
        mLocationRequest = LocationRequest()
        mLocationRequest?.interval = 10000
        mLocationRequest?.fastestInterval = 10000
        mLocationRequest?.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        mLocationRequest?.smallestDisplacement = 100f

        activateLocationSetting(mLocationRequest!!, googleApiClient!!, this)

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.CAMERA)
                .withListener(object : PermissionListener {
                    override fun onPermissionGranted(response: PermissionGrantedResponse?) {
                        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, mLocationRequest, this@FarmerLocationPickerActivity)
                    }

                    override fun onPermissionRationaleShouldBeShown(permission: PermissionRequest?, token: PermissionToken?) {
                    }

                    override fun onPermissionDenied(response: PermissionDeniedResponse?) {
                        Toast.makeText(this@FarmerLocationPickerActivity, "We'll need this permission", Toast.LENGTH_LONG).show()
                    }

                }).check()

    }

    override fun onConnectionSuspended(p0: Int) {

    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {

    }


    override fun onLocationChanged(location: Location?) {
        updateCurrentLocation(location)

    }

    public fun getLocationAccuracy(location: Location?): Int {
        if (location == null) {
            return 0
        }

        return location.accuracy as Int
    }


    fun activateLocationSetting(mLocationRequest: LocationRequest,
                                mGoogleClient: GoogleApiClient, activity: Activity) {

        val locationRequestBuilder = LocationSettingsRequest.Builder().addLocationRequest(mLocationRequest)


        /*When the PendingResult returns, your app can check the location settings by looking at the status
        code from the LocationSettingsResult object. To get even more details about the the current state of
        the relevant location settings, your app can call the LocationSettingsResult object's getLocationSettingsStates() method*/

        val pLocationSettinsResult = LocationServices.SettingsApi.checkLocationSettings(mGoogleClient, locationRequestBuilder.build())

        pLocationSettinsResult.setResultCallback(object : ResultCallback<LocationSettingsResult> {
            override fun onResult(locationSettingsResult: LocationSettingsResult) {

                val status = locationSettingsResult.status
                val locationSettingsStates = locationSettingsResult.locationSettingsStates
                val REQUEST_CHECK_SETTINGS = 2000

                when (status.statusCode) {
                    LocationSettingsStatusCodes.RESOLUTION_REQUIRED ->
                        //Location settings not satisfied but this can be resolved
                        //by showing the user a dialog
                        try {
                            status.startResolutionForResult(activity,
                                    REQUEST_CHECK_SETTINGS)
                        } catch (e: IntentSender.SendIntentException) {
                            Log.e("location settings error", e.message)
                            Toast.makeText(this@FarmerLocationPickerActivity, "Turn on location", Toast.LENGTH_LONG).show()
                        }

                    LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE ->
                        // Location settings are not satisfied. However, we have no way
                        // to fix the settings so we won't show the dialog.
                        Toast.makeText(this@FarmerLocationPickerActivity, "Turn on location", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

}
