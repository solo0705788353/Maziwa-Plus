package net.novacent.maziwaplus.data

import android.content.SharedPreferences
import com.google.gson.Gson
import net.novacent.maziwaplus.MaziwaPlusApplication
import net.novacent.maziwaplus.data.models.User
import net.novacent.maziwaplus.utils.extensions.*

/**
 * Created by kibichii on 8/5/2018.
 */
class AppDataManager(var sharedPreferences: SharedPreferences, var gson: Gson) : DataManager {
    override fun serialize(data: Any?): String {
        return gson.toJson(data)
    }

    override var apiToken: String?
        get() {
            return sharedPreferences.getString(MaziwaPlusApplication.Companion.SharedPreferencesKeys.API_TOKEN, null)
        }
        set(value) {
            sharedPreferences.putString(MaziwaPlusApplication.Companion.SharedPreferencesKeys.API_TOKEN, value)
        }

    override var user: User?
        get() {
            return sharedPreferences
                    .getAsObject(MaziwaPlusApplication.Companion.SharedPreferencesKeys.USER, User::class.java, gson)
        }
        set(value) {
            sharedPreferences.setObject(MaziwaPlusApplication.Companion.SharedPreferencesKeys.USER, value, gson)
        }

    override var loggedIn: Boolean
        get() {
            return sharedPreferences.getBoolean(MaziwaPlusApplication.Companion.SharedPreferencesKeys.LOGGED_IN, false)
        }
        set(value) {
            sharedPreferences.putBoolean(MaziwaPlusApplication.Companion.SharedPreferencesKeys.LOGGED_IN, value)
        }

    override fun <T> deserialize(json: String, clazz: Class<T>): T {
        return gson.fromJson(json, clazz)
    }

    override fun <T> deserialize(data: Any?, clazz: Class<T>): T {
        var json = gson.toJson(data)
        return deserialize(json, clazz)
    }

    override fun <T> deserialize(data: Any?): List<T> {
        return deserialize(gson.toJson(data))
    }

    override fun <T> deserialize(json: String): List<T> {
        var data: List<T> = gson.fromJson<List<T>>(json)
        return data
    }


}