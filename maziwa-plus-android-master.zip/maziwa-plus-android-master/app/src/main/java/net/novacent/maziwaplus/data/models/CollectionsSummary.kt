package net.novacent.maziwaplus.data.models

import java.io.Serializable

/**
 * Created by kibichii on 9/29/2018.
 */
data class CollectionsSummary(
        var weight: Double? = 0.0,
        var count: Int? = 0
) : Serializable