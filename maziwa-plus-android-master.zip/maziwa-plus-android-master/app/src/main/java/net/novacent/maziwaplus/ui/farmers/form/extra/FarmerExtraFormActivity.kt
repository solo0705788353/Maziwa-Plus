package net.novacent.maziwaplus.ui.farmers.form.extra

import android.app.Activity
import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.AppCompatSpinner
import android.support.v7.widget.Toolbar
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import com.basgeekball.awesomevalidation.AwesomeValidation
import com.basgeekball.awesomevalidation.ValidationStyle
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.FarmerDetail
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.farmers.detail.FarmerDetailActivity
import javax.inject.Inject

class FarmerExtraFormActivity : BaseActivity(), FarmerExtraFormContract.View {

    companion object {
        val FARMER_EXTRA: String = FarmerDetailActivity.FARMER_EXTRA
        val FARMER_DETAIL_EXTRA: String? = "farmer_detail_extra"
    }

    val mToolbar: Toolbar by bindView(R.id.toolbar)
    val mFarmerName: TextView by bindView(R.id.farmer_name)
    val mFarmerSupplyNumber: TextView by bindView(R.id.farmer_supply_number)

    val mHerdSize: AppCompatEditText by bindView(R.id.form_herd_size)
    val mMilkingHerdSize: AppCompatEditText by bindView(R.id.form_milking_herd_size)
    val mFarmSize: AppCompatEditText by bindView(R.id.form_farm_size)
    val mOtherFarmingForms: AppCompatEditText by bindView(R.id.form_other_form_of_farming)
    val mFeedsType: AppCompatEditText by bindView(R.id.form_feeds_type)
    val mSubmit: AppCompatButton by bindView(R.id.form_submit)

    var mFarmer: Farmer? = null
    var mFarmerDetail: FarmerDetail? = null

    val mValidation: AwesomeValidation = AwesomeValidation(ValidationStyle.UNDERLABEL)

    var mFarmerExtraFormPresenter: FarmerExtraFormPresenter<FarmerExtraFormContract.View>? = null
        @Inject set

    var mProgressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_extra_form)
        setSupportActionBar(mToolbar)

        if (supportActionBar != null) {
            supportActionBar?.title = "Farmer details"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        mFarmer = intent?.getSerializableExtra(FARMER_EXTRA) as Farmer?

        activityComponent?.inject(this)

        mFarmerExtraFormPresenter?.attach(this)

        init()
    }

    private fun init() {
        mFarmerName.text = "${mFarmer?.surname} ${mFarmer?.otherNames}"
        mFarmerSupplyNumber.text = mFarmer?.supplyNumber

        mProgressDialog = ProgressDialog(this)
        mProgressDialog?.isIndeterminate = true
        mProgressDialog?.setMessage("Updating farmer details...")
        mProgressDialog?.setCancelable(false)

        this.mFarmerDetail = mFarmer?.farmerDetail
        showFarmerDetail(farmerDetail = mFarmerDetail)

        mSubmit.setOnClickListener {
            mFarmerExtraFormPresenter?.onSaveClicked()
        }
    }

    override fun validate(): Boolean = mValidation.validate()

    override fun getFarmerDetail(): FarmerDetail? {
        return FarmerDetail(
                farmer = mFarmer,
                id = mFarmerDetail?.id,
                uuid = mFarmerDetail?.uuid,
                herdSize = Integer.valueOf(mHerdSize.text.toString()),
                milkingHerdSize = Integer.valueOf(mMilkingHerdSize.text.toString()),
                landSize = mFarmSize.text.toString().toDouble(),
                feedsType = mFeedsType.text.toString(),
                otherFarmingForms = mOtherFarmingForms.text.toString()
        )
    }

    override fun showFarmerDetail(farmerDetail: FarmerDetail?) {
        mMilkingHerdSize.setText(this.mFarmerDetail?.milkingHerdSize?.toString())
        mHerdSize.setText(this.mFarmerDetail?.herdSize?.toString())
        mOtherFarmingForms.setText(this.mFarmerDetail?.otherFarmingForms)
        mFarmSize.setText(this.mFarmerDetail?.landSize?.toString())
        mFeedsType.setText(this.mFarmerDetail?.feedsType)

    }

    override fun toggleProgress(show: Boolean) {
        if (show)
            mProgressDialog?.show()
        else
            mProgressDialog?.dismiss()
    }

    override fun onSuccess(farmerDetail: FarmerDetail?) {
        Toast.makeText(this, "Saved", Toast.LENGTH_LONG).show()
        var data = Intent()
        data.putExtra(FARMER_DETAIL_EXTRA, farmerDetail)
        setResult(Activity.RESULT_OK, data)
        finish()
    }


    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
