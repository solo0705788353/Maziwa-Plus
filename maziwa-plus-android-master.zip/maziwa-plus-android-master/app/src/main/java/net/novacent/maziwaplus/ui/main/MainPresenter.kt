package net.novacent.maziwaplus.ui.main

import android.util.Log
import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.data.network.DashboardService
import net.novacent.maziwaplus.data.network.dto.Dashboard
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 9/4/2018.
 */
class MainPresenter<V : MainContract.View> @Inject constructor(
        var dataManager: DataManager,
        var dashboardService: DashboardService,
        var schedulerProvider: SchedulerProvider
) : BasePresenter<V>(), MainContract.Presenter<V> {

    override fun fetchDashboardData() {
        view?.toggleProgress(true)

        dashboardService.fetchDashboard()
                .subscribeOn(schedulerProvider.io())
                .observeOn(schedulerProvider.ui())
                .subscribe({
                    view?.toggleProgress(false)
                    var dashboard = dataManager.deserialize(it.data, Dashboard::class.java)

                    var latestCollections: MutableList<MilkCollection> = mutableListOf()

                    for (o: Any in dashboard.latestCollections) {
                        latestCollections.add(
                                dataManager.deserialize(o, MilkCollection::class.java)
                        )
                    }
                    dashboard.latestCollections = latestCollections

                    view?.onDashboardDataFetched(dashboard)

                }, {
                    view?.onError(it.message)
                    view?.toggleProgress(false)

                })
    }

    override fun onLogoutClicked() {
        dataManager.loggedIn = false
        dataManager.user = null
        view?.onLogoutSuccess()
    }
}