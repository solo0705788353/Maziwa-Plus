package net.novacent.maziwaplus.data.network

import io.reactivex.Observable
import net.novacent.maziwaplus.data.network.dto.Response
import retrofit2.http.GET

/**
 * Created by kibichii on 9/3/2018.
 */
interface UserService {
    @GET("users/me")
    fun userProfile(): Observable<Response>
}