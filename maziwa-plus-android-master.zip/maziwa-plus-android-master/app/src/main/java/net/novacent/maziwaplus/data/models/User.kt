package net.novacent.maziwaplus.data.models

import java.io.Serializable

/**
 * Created by kibichii on 9/2/2018.
 */
data class User(
        var id: Long,
        var uuid: String,
        var username: String,
        var surname: String,
        var otherNames: String,
        var type: String
) : Serializable