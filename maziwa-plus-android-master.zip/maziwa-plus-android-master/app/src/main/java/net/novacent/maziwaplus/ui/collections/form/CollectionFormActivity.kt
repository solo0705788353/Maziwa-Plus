package net.novacent.maziwaplus.ui.collections.form

import android.app.ProgressDialog
import android.os.Bundle
import android.support.v7.widget.AppCompatButton
import android.support.v7.widget.AppCompatCheckBox
import android.support.v7.widget.AppCompatEditText
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import com.basgeekball.awesomevalidation.AwesomeValidation
import com.basgeekball.awesomevalidation.ValidationStyle
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.farmers.detail.FarmerDetailActivity
import javax.inject.Inject

class CollectionFormActivity : BaseActivity(), CollectionFormContract.View {


    companion object {
        val FARMER_EXTRA: String = FarmerDetailActivity.FARMER_EXTRA
    }

    val mToolbar: Toolbar by bindView(R.id.toolbar)
    val mFarmerName: TextView by bindView(R.id.farmer_name)
    val mFarmerSupplyNumber: TextView by bindView(R.id.farmer_supply_number)

    val mMilkQuantity: AppCompatEditText by bindView(R.id.form_milk_quantity)
    val mMilkAlcoholContent: AppCompatEditText by bindView(R.id.form_alcohol_content)
    val mMilkPh: AppCompatEditText by bindView(R.id.form_ph)
    val mBoilingTest: AppCompatCheckBox by bindView(R.id.form_boiling_test)

    val mSubmit: AppCompatButton by bindView(R.id.form_submit)

    var mFarmer: Farmer? = null


    val mValidation: AwesomeValidation = AwesomeValidation(ValidationStyle.UNDERLABEL)

    var mCollectionFormPresenter: CollectionFormPresenter<CollectionFormContract.View>? = null
        @Inject set

    var mProgressDialog: ProgressDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_collection_form)

        setSupportActionBar(mToolbar)

        activityComponent?.inject(this)

        mCollectionFormPresenter?.attach(this)

        if (supportActionBar != null) {
            supportActionBar?.title = "Milk collection"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        mFarmer = intent?.getSerializableExtra(FARMER_EXTRA) as Farmer

        init()
    }

    private fun init() {

        mFarmerName.text = "${mFarmer?.surname} ${mFarmer?.otherNames}"
        mFarmerSupplyNumber.text = mFarmer?.supplyNumber

        mValidation.setContext(this)
        mValidation.addValidation(mMilkQuantity, "^[\\d.]+\$", "Enter milk quantity")
        //mValidation.addValidation(mMilkAlcoholContent, "[0-9\\s]+", "Enter Alcohol content")
        mValidation.addValidation(mMilkPh, "^[6.]+[5-7]\$", "Enter valid PH")

        mSubmit.setOnClickListener {
            mCollectionFormPresenter?.onSubmitClicked()
        }

        mProgressDialog = ProgressDialog(this)
        mProgressDialog?.isIndeterminate = true
        mProgressDialog?.setMessage("Submitting Record...")
        mProgressDialog?.setCancelable(false)

    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> {
                false
            }
        }
    }

    override fun showMilkCollection(milkCollection: MilkCollection?) {
        mMilkQuantity.setText(milkCollection?.weight.toString())
        mMilkAlcoholContent.setText(milkCollection?.alcoholContent.toString())
        mMilkPh.setText(milkCollection?.phValue.toString())
        mBoilingTest.isChecked = milkCollection?.boilingTest!!
    }

    override fun getMilkCollection(): MilkCollection {
        return MilkCollection(
                weight = mMilkQuantity.text.toString().toDouble(),
                alcoholContent = 0.0,
                phValue = mMilkPh.text.toString().toDouble(),
                supplierId = mFarmer?.id!!,
                boilingTest = mBoilingTest.isChecked
        )
    }

    override fun validate(): Boolean {
        return mValidation.validate()
    }


    override fun toggleProgress(show: Boolean) {
        if (show)
            mProgressDialog?.show()
        else
            mProgressDialog?.dismiss()
    }

    override fun onSuccess(milkCollection: MilkCollection?) {
        Toast.makeText(this, "Submitted", Toast.LENGTH_LONG).show()
        showMilkCollection(MilkCollection(
                weight = 0.0, alcoholContent = 0.0, phValue = 0.0
        ))
        finish()
    }

    override fun onError(message: String?) {
        // Toast.makeText(this, "An error occurred. Try again later.", Toast.LENGTH_LONG).show()
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }


}