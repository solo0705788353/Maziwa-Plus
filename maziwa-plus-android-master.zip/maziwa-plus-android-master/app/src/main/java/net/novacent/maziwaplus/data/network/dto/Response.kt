package net.novacent.maziwaplus.data.network.dto

/**
 * Created by KEVIN on 3/14/2018.
 */
data class Response(var data: Any, var code: Int?, var success: Boolean?, var message: String?) {
}