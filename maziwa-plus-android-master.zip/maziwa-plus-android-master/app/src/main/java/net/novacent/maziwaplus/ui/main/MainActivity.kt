package net.novacent.maziwaplus.ui.main

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.data.network.dto.Dashboard
import net.novacent.maziwaplus.ui.auth.login.LoginActivity
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.collections.CollectionsAdapter
import net.novacent.maziwaplus.ui.collections.CollectionsContract
import net.novacent.maziwaplus.ui.farmers.FarmersActivity
import net.novacent.maziwaplus.ui.farmers.form.FarmerFormActivity
import net.novacent.maziwaplus.ui.farmers.search.FarmerSearchActivity
import net.novacent.maziwaplus.utils.ViewAnimation
import javax.inject.Inject

class MainActivity : BaseActivity(), MainContract.View, CollectionsContract.Item {
    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }


    private var rotate = false


    val mFabAdd: FloatingActionButton by bindView(R.id.fab_add)
    val mLayoutAddFarmer: View by bindView(R.id.layout_add_farmer)
    val mAddFarmer: View by bindView(R.id.fab_add_farmer)
    val mLayoutAddCollection: View by bindView(R.id.layout_add_collection)
    val mAddCollection: View by bindView(R.id.fab_add_collection)
    val mBackDrop: View by bindView(R.id.back_drop)

    val mToolbar: Toolbar by bindView(R.id.toolbar)

    val mDashboardRefresh: SwipeRefreshLayout by bindView(R.id.dashboard_refresh)

    val mCollectionsQuantityCount: TextView by bindView(R.id.collections_quantity_count)
    val mRegisteredSuppliersCount: TextView by bindView(R.id.registered_suppliers_count)

    var mMainPresenter: MainPresenter<MainContract.View>? = null
        @Inject set

    var mCollectionsAdapter: CollectionsAdapter? = null

    val mCollectionsList: RecyclerView by bindView(R.id.recent_collections_list)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        activityComponent?.inject(this)

        mMainPresenter?.attach(this)

        init()

        mFabAdd.setOnClickListener {
            toggleFabMode(it)
        }

        mAddFarmer.setOnClickListener {
            var intent = Intent(this@MainActivity, FarmerFormActivity::class.java)
            startActivity(intent)
            resetFab()
        }

        mAddCollection.setOnClickListener {
            var intent = Intent(this@MainActivity, FarmerSearchActivity::class.java)
            intent.putExtra(FarmersActivity.ACTION, 1)
            startActivity(intent)
            resetFab()
        }

        mCollectionsAdapter = CollectionsAdapter(this, mutableListOf<MilkCollection>(), this)
        mCollectionsList.layoutManager = LinearLayoutManager(this)
        mCollectionsList.adapter = mCollectionsAdapter

    }

    private fun resetFab() {
        toggleFabMode(mFabAdd)
    }

    private fun init() {
        ViewAnimation.initShowOut(mLayoutAddFarmer)
        ViewAnimation.initShowOut(mLayoutAddCollection)

        setSupportActionBar(mToolbar)

        if (supportActionBar != null) {
            supportActionBar?.title = "Maziwa +"
        }

        mDashboardRefresh.setOnRefreshListener {
            mMainPresenter?.fetchDashboardData()
        }
    }

    private fun toggleFabMode(v: View) {
        rotate = ViewAnimation.rotateFab(v, !rotate)
        if (rotate) {
            ViewAnimation.showIn(mLayoutAddFarmer)
            ViewAnimation.showIn(mLayoutAddCollection)
            mBackDrop.visibility = View.VISIBLE
        } else {
            ViewAnimation.showOut(mLayoutAddFarmer)
            ViewAnimation.showOut(mLayoutAddCollection)
            mBackDrop.visibility = View.GONE
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onLogoutSuccess() {
        var intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            R.id.action_logout -> {
                mMainPresenter?.onLogoutClicked()
                true
            }
            else -> {
                false
            }
        }
    }

    override fun toggleProgress(show: Boolean) {
        if (show) {
            mDashboardRefresh.post {
                mDashboardRefresh.isRefreshing = true
            }
        } else
            mDashboardRefresh.isRefreshing = false
    }

    override fun onDashboardDataFetched(dashboard: Dashboard) {
        mCollectionsQuantityCount.text = dashboard.collectionsCount.toString()
        mRegisteredSuppliersCount.text = dashboard.suppliersCount.toString()
        mCollectionsAdapter?.items = dashboard.latestCollections
        mCollectionsAdapter?.notifyDataSetChanged()
    }

    override fun onResume() {
        super.onResume()
        mMainPresenter?.fetchDashboardData()
    }

    override fun onClick(milkCollection: MilkCollection) {

    }
}
