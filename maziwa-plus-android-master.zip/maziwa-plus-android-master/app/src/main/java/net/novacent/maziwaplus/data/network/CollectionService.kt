package net.novacent.maziwaplus.data.network

import io.reactivex.Observable
import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.data.network.dto.Response
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Created by kibichii on 8/25/2018.
 */
interface CollectionService {
    @POST("collections")
    fun create(@Body milkCollection: MilkCollection?): Observable<Response>
}