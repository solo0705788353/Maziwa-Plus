package net.novacent.maziwaplus.ui.farmers.form

import android.util.Log
import net.novacent.maziwaplus.utils.scheduler.SchedulerProvider
import net.novacent.maziwaplus.data.DataManager
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.data.network.FarmerService
import net.novacent.maziwaplus.ui.base.BasePresenter
import javax.inject.Inject

/**
 * Created by kibichii on 8/26/2018.
 */
class FarmerFormPresenter<V : FarmerFormContract.View>
@Inject constructor(var farmerService: FarmerService, var schedulerProvider: SchedulerProvider, var dataManager: DataManager)
    : BasePresenter<V>(), FarmerFormContract.Presenter<V> {


    override fun onSubmitClicked() {
        if (this.view?.validate()!!) {
            var farmer: Farmer? = view?.getFarmer()

            view?.toggleProgress(true)
            this.farmerService
                    .createFarmer(farmer)
                    .subscribeOn(schedulerProvider.io())
                    .observeOn(schedulerProvider.ui())
                    .subscribe({
                        view?.toggleProgress(false)
                        var createdFarmer: Farmer? = dataManager.deserialize(it.data, Farmer::class.java)
                        Log.d("CReated: ", dataManager.serialize(createdFarmer))
                        view?.onSuccess(createdFarmer)
                    }, {
                        view?.toggleProgress(false)

                    })
        }
    }
}