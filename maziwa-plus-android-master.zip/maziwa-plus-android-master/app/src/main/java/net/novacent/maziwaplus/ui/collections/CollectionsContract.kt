package net.novacent.maziwaplus.ui.collections

import net.novacent.maziwaplus.data.models.MilkCollection
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 8/5/2018.
 */
interface CollectionsContract {
    interface View : BaseContract.View {
        fun onCollectionsFetched()

    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun fetchCollections()
    }

    interface Item {
        fun onClick(milkCollection: MilkCollection)
    }
}