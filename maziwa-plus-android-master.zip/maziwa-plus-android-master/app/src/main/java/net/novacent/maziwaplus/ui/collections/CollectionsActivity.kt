package net.novacent.maziwaplus.ui.collections

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import net.novacent.maziwaplus.R

class CollectionsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_collections)
    }
}
