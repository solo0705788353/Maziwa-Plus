package net.novacent.maziwaplus.data.models

import java.io.Serializable
import java.util.*

/**
 * Created by kibichii on 8/16/2018.
 */
data class Farmer(
        var id: Long? = 0,
        var uuid: String? = "",
        var surname: String? = "",
        var otherNames: String = "",
        var idNumber: String = "",
        var phoneNumber: String = "",
        var supplyNumber: String? = "",
        var dateOfBirth: Date? = null,
        var supplierLocation: FarmerLocation? = FarmerLocation(),
        var farmerDetail: FarmerDetail? = null,
        var collectionsSummary: CollectionsSummary? = CollectionsSummary(),
        var monthlyCollectionsSummary: CollectionsSummary? = CollectionsSummary()
) : Serializable {
    fun getFullName(): String {
        return "$surname $otherNames"
    }
}