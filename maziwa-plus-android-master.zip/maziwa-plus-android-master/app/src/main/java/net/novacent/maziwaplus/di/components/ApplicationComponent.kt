package net.novacent.maziwaplus.di.components

import dagger.Component
import net.novacent.maziwaplus.MaziwaPlusApplication
import net.novacent.maziwaplus.di.modules.ApplicationModule

/**
 * Created by kibichii on 8/25/2018.
 */
@Component(modules = [ApplicationModule::class])
interface ApplicationComponent {
    fun inject(maziwaPlusApplication: MaziwaPlusApplication)
}