package net.novacent.maziwaplus.ui.farmers

import android.content.Intent
import android.os.Bundle
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.DividerItemDecoration
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.Menu
import android.view.MenuItem
import android.widget.LinearLayout
import android.widget.Toast
import kotterknife.bindView
import net.novacent.maziwaplus.R
import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.ui.base.BaseActivity
import net.novacent.maziwaplus.ui.collections.form.CollectionFormActivity
import net.novacent.maziwaplus.ui.farmers.detail.FarmerDetailActivity
import java.util.*
import javax.inject.Inject

class FarmersActivity : BaseActivity(), FarmersContract.View, FarmersContract.Item {

    companion object {
        public val ACTION: String = "action"
    }

    val mFarmersList: RecyclerView by bindView(R.id.farmers_list)
    var mFarmersAdapter: FarmersAdapter? = null

    val mToolbar: Toolbar by bindView(R.id.toolbar)

    val mFarmersRefresh: SwipeRefreshLayout by bindView(R.id.farmers_refresh)

    var mFarmersPresenter: FarmersPresenter<FarmersContract.View>? = null
        @Inject set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmers)

        activityComponent?.inject(this)

        mFarmersPresenter?.attach(this)

        setSupportActionBar(mToolbar)

        if (supportActionBar != null) {
            supportActionBar?.title = "Farmers"
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
        init()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_farmers, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> {
                false
            }
        }
    }

    private fun init() {
        var farmers = mutableListOf<Farmer>()
        /*  farmers.add(Farmer(1, "Kibichii", "Washington", UUID.randomUUID().toString()))
          farmers.add(Farmer(2, "Kevin", "Kibet", UUID.randomUUID().toString()))
          farmers.add(Farmer(3, "Elkana", "Tuwei", UUID.randomUUID().toString()))*/

        mFarmersAdapter = FarmersAdapter(this, farmers, this)
        mFarmersList.layoutManager = LinearLayoutManager(this)
        mFarmersList.addItemDecoration(DividerItemDecoration(this, LinearLayout.VERTICAL))
        mFarmersList.adapter = mFarmersAdapter

        mFarmersPresenter?.fetchFarmers()

        mFarmersRefresh.setOnRefreshListener {
            mFarmersPresenter?.fetchFarmers()
        }
    }

    override fun itemClicked(farmer: Farmer) {
        var intent = Intent(this@FarmersActivity, FarmerDetailActivity::class.java)
        intent.putExtra(FarmerDetailActivity.FARMER_EXTRA, farmer)
        startActivity(intent)
    }

    override fun toggleProgress(show: Boolean) {
        if (show) {
            mFarmersRefresh.post {
                mFarmersRefresh.isRefreshing = true
            }
        } else {
            mFarmersRefresh.isRefreshing = false
        }
    }

    override fun onSuccess(farmers: List<Farmer>) {
        mFarmersAdapter?.farmers = farmers
        mFarmersAdapter?.notifyDataSetChanged()
    }

    override fun onError(message: String?) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
