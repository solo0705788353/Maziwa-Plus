package net.novacent.maziwaplus.utils.extensions

import android.content.SharedPreferences
import com.google.gson.Gson

/**
 * Created by KEVIN on 3/28/2018.
 */


fun <T> SharedPreferences.getAsObject(key: String, clazz: Class<T>, gson: Gson): T? {
    var value = this.getString(key, null)
    if (value == null) {
        return null
    } else {
        return gson.fromJson(value, clazz)
    }
}

fun SharedPreferences.setObject(key: String, data: Any?, gson: Gson) {
    var value = gson.toJson(data)
    this.putString(key, value)
}

fun SharedPreferences.putString(key: String, data: String?) {
    var editor: SharedPreferences.Editor = this.edit()
    editor.putString(key, data)
    editor.apply()
}

fun SharedPreferences.putBoolean(key: String, data: Boolean) {
    var editor: SharedPreferences.Editor = this.edit()
    editor.putBoolean(key, data)
    editor.apply()
}