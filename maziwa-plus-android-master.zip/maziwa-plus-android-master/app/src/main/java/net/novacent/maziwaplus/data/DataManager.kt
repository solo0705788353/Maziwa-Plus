package net.novacent.maziwaplus.data

import net.novacent.maziwaplus.data.models.User

/**
 * Created by kibichii on 8/5/2018.
 */
interface DataManager {
    var apiToken: String?

    var user: User?

    var loggedIn: Boolean

    fun serialize(data: Any?): String

    fun <T> deserialize(json: String, clazz: Class<T>): T

    fun <T> deserialize(data: Any?, clazz: Class<T>): T

    fun <T> deserialize(json: String): List<T>

    fun <T> deserialize(data: Any?): List<T>

}