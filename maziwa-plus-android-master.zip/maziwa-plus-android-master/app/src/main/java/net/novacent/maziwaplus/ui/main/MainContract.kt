package net.novacent.maziwaplus.ui.main

import net.novacent.maziwaplus.data.network.dto.Dashboard
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 9/4/2018.
 */
interface MainContract {
    interface View : BaseContract.View {
        fun onLogoutSuccess()

        fun toggleProgress(show: Boolean)

        fun onDashboardDataFetched(dashboard: Dashboard)

        fun onError(message: String?)

    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onLogoutClicked()

        fun fetchDashboardData()
    }
}