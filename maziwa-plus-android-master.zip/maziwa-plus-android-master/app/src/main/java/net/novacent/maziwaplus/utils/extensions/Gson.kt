package net.novacent.maziwaplus.utils.extensions

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * Created by KEVIN on 4/7/2018.
 */

inline fun <reified T> Gson.fromJson(json: String) = this.fromJson<T>(json, object : TypeToken<T>() {}.type)


