package net.novacent.maziwaplus.data.models

import java.io.Serializable

/**
 * Created by kibichii on 8/22/2018.
 */
data class FarmerDetail(
        var uuid: String? = "",
        var id: Long? = 0,
        var farmer: Farmer? = null,
        var herdSize: Int? = 0,
        var milkingHerdSize: Int? = 0,
        var feedsType: String? = "",
        var landSize: Double? = 0.0,
        var otherFarmingForms: String? = ""
) : Serializable