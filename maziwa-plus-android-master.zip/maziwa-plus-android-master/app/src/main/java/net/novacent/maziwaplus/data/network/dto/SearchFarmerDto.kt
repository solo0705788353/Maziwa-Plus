package net.novacent.maziwaplus.data.network.dto

/**
 * Created by kibichii on 8/25/2018.
 */
data class SearchFarmerDto(var query: String) {
}