package net.novacent.maziwaplus.ui.farmers

import net.novacent.maziwaplus.data.models.Farmer
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 8/5/2018.
 */
interface FarmersContract {
    interface View : BaseContract.View {
        fun toggleProgress(show: Boolean)

        fun onSuccess(farmers: List<Farmer>)

        fun onError(message: String?)
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun fetchFarmers()
    }

    interface Item {
        fun itemClicked(farmer: Farmer)
    }
}