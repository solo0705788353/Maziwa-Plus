package net.novacent.maziwaplus.ui.farmers.form.extra

import net.novacent.maziwaplus.data.models.FarmerDetail
import net.novacent.maziwaplus.ui.base.BaseContract

/**
 * Created by kibichii on 9/29/2018.
 */
interface FarmerExtraFormContract {
    interface View : BaseContract.View {
        fun validate(): Boolean

        fun getFarmerDetail(): FarmerDetail?

        fun toggleProgress(show: Boolean)

        fun onSuccess(farmerDetail: FarmerDetail?)

        fun showFarmerDetail(farmerDetail: FarmerDetail?)

        fun onError(message: String?)
    }

    interface Presenter<V : View> : BaseContract.Presenter<V> {
        fun onSaveClicked()
    }
}